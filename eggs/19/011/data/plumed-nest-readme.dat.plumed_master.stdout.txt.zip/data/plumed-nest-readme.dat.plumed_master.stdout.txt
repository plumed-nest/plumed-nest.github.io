PLUMED: PLUMED is starting
PLUMED: Version: 2.10.0-dev (git: 0d91387fa) compiled on Mar 27 2024 at 15:42:49
PLUMED: Please cite these papers when using PLUMED [1][2]
PLUMED: For further information see the PLUMED web page at http://www.plumed.org
PLUMED: Root: /home/runner/opt/lib/plumed_master
PLUMED: LibraryPath: /home/runner/opt/lib/libplumed_masterKernel.so
PLUMED: For installed feature, see /home/runner/opt/lib/plumed_master/src/config/config.txt
PLUMED: Molecular dynamics engine: driver
PLUMED: Precision of reals: 8
PLUMED: Running over 1 node
PLUMED: Number of threads: 1
PLUMED: Cache line size: 512
PLUMED: Number of atoms: 100000
PLUMED: File suffix: 
PLUMED: FILE: plumed-nest-readme.dat
PLUMED: Action ENDPLUMED
PLUMED:   with label @0
PLUMED: END FILE: plumed-nest-readme.dat
PLUMED: Timestep: 1.000000
PLUMED: KbT: 2.490000
PLUMED: Relevant bibliography:
PLUMED:   [1] The PLUMED consortium, Nat. Methods 16, 670 (2019)
PLUMED:   [2] Tribello, Bonomi, Branduardi, Camilloni, and Bussi, Comput. Phys. Commun. 185, 604 (2014)
PLUMED: Please read and cite where appropriate!
PLUMED: Finished setup
PLUMED:                                               Cycles        Total      Average      Minimum      Maximum
PLUMED:                                                    1     0.006406     0.006406     0.006406     0.006406
